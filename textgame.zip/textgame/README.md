# textgame

CRYING BABY

Länk till GitHub = https://github.com/elinalm/textgame

Demolänk =  https://elinalm.github.io/textgame/

Spelet jag har gjort går ut på att få bebisen Sture att sluta gråta. 
Jag har använt mig av funktioner med tillhörande if:s och else:s för 
att få mitt spel att fungera så jag vill. 
Det första som händer är att du kommer till köket för att ge Sture mat. 
Två av alternativen ger GAME OVER, det tredje alternativet gör att du kommer
vidare till badrummet för att byta Stures blöja. 
I badrummet finns det två funktioner. Två av alternativen ger GAME OVER. Ett
av alterniven tar dig vidare till ytterligare en funktion i badrummet. I den funktionen
är ett av alterniven som var GAME OVER i första funktionen i badrummet rätt. 
Nu kommer du vidare till vardagsrummet för att leka. Ett av alternativen tar 
dig vidare till sovrummet för att natta Sture. 
I Sovrummet får du tre alternativ för hur du ska natta honom. Inget av de tre alterniven tar 
dig vidare. När du väljer ett av alternativen en andra gång kommer du vidare och 
klarar spelet. 


I min HTML-fil har jag en div där jag ger en kort förklaring om vad 
spelet går ut på. I diven finns en knapp som startar spelet och visar
då den första prompten. 


I min css-fil finns ligger endast stylingen till sidan. 


I min script-fil finns alla funktionerna. Där jag endast använder mig av 
lokala variabler i funktionerna. 

